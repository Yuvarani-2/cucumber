package stepDefinitions;

public class PluginDefinitions {

}
