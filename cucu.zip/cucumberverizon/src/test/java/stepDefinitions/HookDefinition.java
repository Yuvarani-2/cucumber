package stepDefinitions;

import io.cucumber.java.*;
import io.cucumber.java.en.*;

public class HookDefinition {
	@Before("@SmokeTest")
	public void beforeFeature()
	{
		System.out.println("Before Scenario");
	}
	@After("@SmokeTest")
	public void afterFeature()
	
	{
		System.out.println("After Scenario");
	}

/*	@Before("@MobileTest")
	public void beforeMobileTest()
	{
		System.out.println("Before ScenarioMobile");
	}
	@After("@MobileTest")
	public void afterMobileTest()
	{
		System.out.println("After ScenarioMobile");
	}*/
	
	@Given("example of given one")
	public void example_of_given_one() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("given example one");
	}

	@When("example of when one")
	public void example_of_when_one() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("when example one");
	}

	@Then("example of then one")
	public void example_of_then_one() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("then example one");
	}

	@Given("example of given two")
	public void example_of_given_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("given example two");
	}

	@When("example of when two")
	public void example_of_when_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("when example two");
	}

	@Then("example of then two")
	public void example_of_then_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("then example two");
	}



}
