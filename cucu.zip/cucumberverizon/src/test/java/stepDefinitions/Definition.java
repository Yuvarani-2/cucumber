package stepDefinitions;




import java.util.List;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

public class Definition {

	@Given("User is on the login screen")
	public void user_is_on_the_login_screen() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("**Given**");
	}
	@When("User provides correct username")
	public void user_provides_correct_username(DataTable data) {
	   
		// Write code here that turns the phrase above into concrete actions
		List<String> table=data.asList();
	    System.out.println(table.get(0));
	}
	@When("User provides correct password={string}")
	public void user_provides_correct_password(String p) {
	    // Write code here that turns the phrase above into concrete actions
	   //System.out.println("**When Part2**"+p);
	}
	@Then("User must login")
	public void user_must_login() {
	    // Write code here that turns the phrase above into concrete actions
	    //System.out.println("**Then Part1**");
	}
	@Then("error should not be there")
	public void error_should_not_be_there() {
	    // Write code here that turns the phrase above into concrete actions
		
        System.out.println("**Then Part2**");
	}

}
