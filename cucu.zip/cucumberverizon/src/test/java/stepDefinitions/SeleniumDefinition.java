package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;
import io.cucumber.java.en.*;


public class SeleniumDefinition {
	

	WebDriver driver;
	/*@Given("user is on the home page")
	public void user_is_on_the_home_page()throws InterruptedException {
		// TODO Auto-generated method stub
		
	}*/
	@Given("user is on MakeMyTrip page")
	public void user_is_on_make_my_trip_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		   driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.makemytrip.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  JavascriptExecutor js=(JavascriptExecutor)driver;
		   
		  js.executeScript("document.elementFromPoint(0,0).click()");
		  driver.findElement(By.className("wewidgeticon we_close")).click();
	}
	@When("user enters phoneNumber {string}") 
	public void user_enters_phone_number(String string) throws InterruptedException {
	 // Write code here that turns the phrase above into concrete actions
		
	 driver.findElement(By.id("username")).sendKeys(string);
	 Thread.sleep(3000);
	 }
	@When("user clicks continue")
	public void user_clicks_continue()  throws InterruptedException {
	 // Write code here that turns the phrase above into concrete actions
	 driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();
	 Thread.sleep(3000);
	 }
	 @Then("otp is sent {string}")
	 public void otp_is_sent(String string) throws InterruptedException {
	 // Write code here that turns the phrase above into concrete actions
	 driver.findElement(By.name("otp")).sendKeys(string);
	 Thread.sleep(3000);
	 }
	 @Then("user is able to login")
	 public void user_is_able_to_login() throws InterruptedException {
	 // Write code here that turns the phrase above into concrete actions
	 driver.findElement(By.xpath("//span[text()='Login']")).click();
	 Thread.sleep(3000);
	 JavascriptExecutor js=(JavascriptExecutor)driver;
	 js.executeScript("document.elementFromPoint(0,0).click()");
	 } 
	
	}
